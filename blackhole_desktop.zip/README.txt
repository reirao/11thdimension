BLACKHOLE Desktop Seed (Windows)

Build:
  build_tcc.bat

Run:
  blackhole_desktop.exe

Seed modes:
  Z           - self-sim seed (reseed from current view)
  X           - desktop screenshot seed
  R / Enter   - reseed current mode
  0           - reset view

View controls:
  Mouse wheel - zoom at cursor
  + / -       - zoom at center
  Arrows      - pan
  Shift+click - center view

Other controls:
  Left click  - place blackhole
  Right click - clear blackhole
  P           - pause/resume
  C           - clear blackhole
  T           - toggle trails
  D           - toggle debug overlay
  M           - toggle macro layer
  I           - toggle inspector (nearest particle)
  F           - toggle family coupling
  , / .       - decrease/increase gravity
  H           - toggle menu
  L           - dump event log to C:\TOOLS\BLACKHOLE\ring.dat
  Esc         - exit

Notes:
- Self-sim mode creates a new universe from the current view; zoom + reseed reveals more detail.
- Macro layer classifies dense regions (gas, star, blue giant, blackhole) and feeds forces back.
- All logging is simulation-only; no system input capture.
